package selenium;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import driver.driver;
public class selenium extends driver{
public void abrir() {
	System.setProperty("webdriver.chrome.driver","driver/chromedriver.exe");
	driver= new ChromeDriver();
}
public void abrirpagina() {
	driver.get("https://bits-angular-stg.dev01.bitsamericas.net/contactenos");
	driver.manage().window().maximize();
}
public void llenarlosdatosdelformulario() throws InterruptedException, AWTException {
	Thread.sleep(10000);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	WebElement correo= driver.findElement(By.xpath("//input[@id='contact_us__correo_electronico']"));
	js.executeScript("arguments[0].scrollIntoView();", correo);
	correo.sendKeys("solocisf390@gmail.com");
	WebElement telefono= driver.findElement(By.xpath("//input[@id='contact_us__telefono']"));
	telefono.sendKeys("3168623014");
	WebElement Nombre= driver.findElement(By.xpath("//input[@id='contact_us__nombre']"));
	Nombre.sendKeys("Javier Andres Castillo Guzman");
	WebElement organizacion= driver.findElement(By.xpath("//input[@id='contact_us__organizacion']"));
	organizacion.sendKeys("automatizadora");
	WebElement ciudad= driver.findElement(By.xpath("//input[@id='contact_us__ciudad']"));
	ciudad.sendKeys("Bogota");
	WebElement Prueba= driver.findElement(By.xpath("//input[@id='contact_us__prueba2020']"));
	Prueba.sendKeys("Prueba Tecnica");
	WebElement opcion= driver.findElement(By.xpath("//ng-select[@id='contact_us__productos_de_interes']/div/div[2]/span/i"));
	opcion.click();
	Robot robot = new Robot();
    robot.mouseMove(300, 500);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    WebElement Comentario= driver.findElement(By.xpath("//textarea[@id='contact_us__comentario']"));
	Comentario.sendKeys("Prueba para automatizador");
	robot.mouseMove(600, 650);
	robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    WebElement boton= driver.findElement(By.xpath("//*[@id=\"formulario_contacto\"]/button"));
	boton.click();

}
public void verificarlaopcionpais() {
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript ("window.scrollBy (0,-350)");
	WebElement Pais= driver.findElement(By.xpath("//ng-select[@id='contact_us__pais']/div/div[2]/span"));
	Pais.click();
}
}

